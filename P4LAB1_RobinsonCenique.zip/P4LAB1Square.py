import turtle  

turtle.speed(2) 

for _ in range(4):   
    turtle.forward(100)  
    turtle.right(90)  

turtle.done()

