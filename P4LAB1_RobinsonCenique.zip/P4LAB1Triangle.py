import turtle

turtle.speed(2)  

sides = 0
while sides < 3:
    turtle.forward(100) 
    turtle.left(120)  
    sides += 1  

turtle.done()

